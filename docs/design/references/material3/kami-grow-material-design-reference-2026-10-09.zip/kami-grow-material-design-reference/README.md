# Kami Grow — approved Material design reference

Owner-approved Tonal overview direction, with the 2026-10-09 light-mode refinement.
Implementation parent: https://github.com/haggaikaunda/kami-split/issues/223

This pack is design evidence and an interactive mockup. It is not the production application, a financial implementation, an authorization model, or proof of production acceptance. The issue's acceptance criteria and current authenticated production contracts govern behavior. All expenses, amounts and other people in these mockups are sample data; `haggai@example.com` is a placeholder. No credentials or real financial records are included.

## Open the mockups

1. Extract the ZIP.
2. Open `desktop.html` and `mobile.html` in a current browser. They are standalone exports and do not require Codex, the repository, a backend, login or a build. Original banner artwork is embedded. The standalone wrappers load pinned Lucide and Floating UI libraries from public CDNs, so full visual fidelity requires network access. Google Fonts is optional with Arial fallback. The included screenshots remain usable offline.
3. If your browser restricts local files, serve this directory locally with `python3 -m http.server 8000 --bind 127.0.0.1`, then open `http://127.0.0.1:8000/desktop.html` or `/mobile.html`.
4. The initial screen is Household → Expenses in Dark. To see the new soft Light palette, select **Account → Light**, then return to Household/Groups/Trips → Overview. Browser-local presentation state may restore your last theme/view; use a fresh browser profile for a clean starting state.

The mobile export contains a centered app up to 390 CSS pixels wide, with its own responsive container. It remains a mobile preview even in a desktop browser. The desktop export adapts to smaller browser widths too. The surrounding dot pattern is preview framing, not product styling.

## Walkthrough

- **Overview:** Select Household, Groups or Trips, then Overview. Compare pale light-mode cards/banner with strong dark-mode contrast. See Your share replacing Household Active spaces. Desktop has a balances sidebar; mobile omits that sidebar and keeps Balances as its own tab. Group and Trip buttons select sample workspaces; production must retain real discovery/create flows.
- **Expense detail:** Select a recent or listed expense. Desktop opens a right drawer; click the scrim anywhere outside the panel, or use Escape/X, to close. Mobile replaces the app shell with an expense detail page and Back to expenses.
- **Editing:** Select Edit expense; edit inside the same drawer/page. Save updates the local sample data. Closing retains the local draft while this preview remains loaded; reopen to continue or Discard. Production must use its existing durable actor-scoped recovery, all split modes and version/authorization rules instead of these sample handlers.
- **Combined filters:** On Household → Expenses → List, open Filters. Select Space, Category, Member, From and To together, then Apply. Five chips remain active with AND semantics. Reset changes the filter draft; closing without Apply keeps active values. Remove individual chips or Clear all. The preview's sample Member IDs are source-scoped.
- **Breakdown:** In Expenses select Breakdown. Switch Total expenses/Your share, select a legend category, then View expenses. Other active filters are retained. Try a source/category combination with no matches. The chart aggregates the full sample array; production requires complete server-authorized aggregates and coherent anchors.
- **Account:** Inspect the compact Profile, Appearance and Session sections in both widths/themes. Only visual layout is authoritative: current production email is read-only and appearance uses explicit guarded Save; local mock controls are not a replacement for those contracts.

## Approved decisions

Main navigation: Household, Groups, Trips, Account.
Workspace tabs: Overview, Expenses, Balances, Activity, Members.
Overview cards: Total expenses, Your net balance, Your share.
Expenses secondary views: List and Breakdown (not another primary tab).

Dark mode: navy backgrounds, mint actions, white summary values, distinct icon/category colors.
Light mode: pale blue-grey, mint and lavender cards, dark text, soft borders, pale illustrated title banner. The owner's earlier light screenshot showing dark filled cards/banner is superseded by these files and `desktop-light-overview.jpg`.
Keep the original pictures: repository `apps/web/public/art/household.png` and `trip.png`. This pack embeds compressed display copies; production should reuse appropriate repository assets. The sprout logo is representative; do not replace the existing brand solely to match it.

## Critical differences from production

| Mockup simplification | Required production behavior |
| --- | --- |
| Four sample members and equal split in edit | Preserve Equal, Exact and Percentage, participant controls, zero shares, payer/creator distinction and exact rounding |
| Local arrays/in-memory mutations | Existing Relay/API reads/writes, complete aggregates, fresh server authorization and original-source boundaries |
| Local draft Map and sample save | Existing actor/source/expense/operation isolation, reload recovery, frozen unknown attempts, duplicate suppression, version conflicts and logout cleanup |
| Local profile name/email save | Guarded display-name update; existing signed-in email stays read-only |
| Instant local theme selection | Existing explicit Save appearance, expected preference, uncertainty reconciliation, persisted account theme and cache lifecycle |
| Sign-out toast and small member/invitation/activity examples | Real sessions, scoped ownership/invitation recovery, complete activity and source-aware history |
| In-memory filter/view navigation | Existing URL filters/detail selection, paging, scroll/focus restoration, Back/Forward and direct links |
| Number cents and bounded fixture amounts | Production canonical exact strings/minor units/BigInt throughout the full supported range |
| Preview includes presentational controls | No sample data, preview badges, Tweak controls, fake API responses or snapshot runtime in production |

The readable source fragments are in `source/`. They use product-prefixed CSS and embedded scripts but also include earlier unused layout rules; they are reference material, not code to transplant. Extract a coherent token/component system into the current application. `desktop.html`/`mobile.html` are rendered standalone wrappers around those fragments.

## Screenshots

- `desktop-light-overview.jpg` — latest softened cards and illustrated banner, the Light authority.
- `desktop-dark-overview.jpg` — white monetary headlines, colored icons, desktop sidebar.
- `desktop-light-account.jpg` — compact profile/appearance/session layout.
- `desktop-dark-expense-drawer.jpg` — right-hand detail and viewport scrim.
- `desktop-dark-expense-edit.jpg` — edit in place; sample equal split only.
- `desktop-dark-combined-filters.jpg` — five simultaneous filter dimensions.
- `desktop-dark-breakdown.jpg` — complete sample category donut and legend.
- `mobile-light-overview.jpg` — responsive summary cards, retained art and bottom navigation; no overview balance list.
- `mobile-light-account.jpg` — stacked settings and compact appearance choices.
- `mobile-dark-expense-detail.jpg` — dedicated mobile detail page.
- `mobile-dark-expense-edit.jpg` — editing in the same mobile page.
- `mobile-dark-breakdown.jpg` — chart and legend reflow.

Desktop captures are 1280px browser width. Phone captures use a 390px app inside 422px of preview framing; an additional 320px app-width check exercised detail editing and Breakdown with no horizontal overflow. Screenshot borders/padding belong to the exported preview, not the production viewport.

## Reference verification and provenance

Created 2026-10-09 from the owner's approved interactive mockups and latest explicit light-mode correction. Repository inspection baseline: `e7f76f58999a42c12842e70c8ba6b898fd17c6d1` (clean main synchronized with origin/main). No production files were changed to create this pack.

Browser checks on this revision: softened Light group and Household overview; Dark overview; desktop outside-click dismissal; in-place edit controls; five filters applied together (4 matching Home expenses, $454.10 total and $113.52 viewer share); complete sample Breakdown ($1,816.00 total across 16 expenses); mobile detail uses page mode and hides the underlying shell; mobile Overview hides the balances list; mobile editing and chart fit a 320px app width. Screenshots were visually inspected. Color-pair checks are in `contrast-check.json`; they do not certify whole-app WCAG compliance or text on every image crop.

Earlier interaction checks of the same prototype logic covered save/remainders, draft reopen, filter draft Reset/Apply, list/chart parity, category drill-down and narrow layouts. These checks concern illustrative sample behavior only. Future production work must run the independent tests, real browser/API checks, CI and final-diff review required by issue #223 and the repository workflow.

`SHA256SUMS` records the packaged file hashes. On macOS use `shasum -a 256 -c SHA256SUMS`; on Linux use `sha256sum -c SHA256SUMS` from this directory.
