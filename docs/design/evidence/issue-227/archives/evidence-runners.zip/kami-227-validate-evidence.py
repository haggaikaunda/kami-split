from pathlib import Path
import json,zipfile,hashlib,re,sys
root=Path(sys.argv[1]); records=[]; total=0
sha=lambda b:hashlib.sha256(b).hexdigest()
secret=re.compile(r'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}|postgres(?:ql)?://[^\s]+:[^\s]+@|(?:access_token|refresh_token|service_role)\s*["\x27:]\s*["\x27][^"\x27\s]{8,}')
for p in sorted((root/'archives').glob('*.zip')):
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None,p
  names=z.namelist(); assert len(names)==len(set(names)),p
  assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names),p
  manifest={x['file']:x for x in json.loads(z.read('image-manifest.json'))['files']} if 'image-manifest.json' in names else None
  for n in names:
   b=z.read(n)
   if n.endswith(('.json','.log','.md','.cjs','.py')):
    assert not secret.search(b.decode()),(p,n,'credential marker')
   if manifest is not None and n!='image-manifest.json':
    assert n in manifest,(p,n,'missing manifest')
    assert sha(b)==manifest[n]['sha256'],(p,n,'checksum')
   total+=1
  assert p.stat().st_size<50_000_000,p
  records.append({'file':'archives/'+p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(names)})
for p in (root/'reports').glob('*'):
 if p.is_file():assert not secret.search(p.read_text()),(p,'credential marker')
for item in json.loads((root/'previews'/'manifest.json').read_text()):
 assert sha((root/'previews'/item['file']).read_bytes())==item['sha256'],item
(root/'archives.json').write_text(json.dumps({'note':'CRC, manifest checksums, archive path safety and publishable credential scan passed. Pixel conversion verification is recorded per image manifest.','archives':records},indent=2)+'\n')
print(json.dumps({'archives':len(records),'filesVerified':total,'totalBytes':sum(x['bytes'] for x in records),'crc':'pass','manifestSha256':'pass','credentialScan':'pass','previewSha256':'pass'},indent=2))
