import json,pathlib,collections,os
base=pathlib.Path('/private/tmp');ref=base/'kami-227-standards-reference';app=pathlib.Path(os.environ.get('APP_EVIDENCE_DIR',str(base/'tester-227-9605a1-matrix')))
pairs={'.kg-metrics':'.ui-summary-row','.kg-metric':'.ui-summary-metric','.kg-number':'.ui-metric-value','.kg-heading':'.ui-workspace-header','.kg-tabs':'.ui-workspace-tabs','.kg-account-fields':'.account-profile-fields','.kg-settings-section':'.account-card','.kg-theme-options':'.appearance-options','.kg-theme-options button':'.appearance-choice','.kg-profile-heading':'.account-identity'}
attrs=['fontSize','fontWeight','color','background','radius','padding','gap'];findings=[]
for rp in ref.glob('*.json'):
 ap=app/rp.name
 if not ap.exists():continue
 r=json.loads(rp.read_text());a=json.loads(ap.read_text())
 if not isinstance(r,dict) or not isinstance(a,dict):continue
 re=r.get('metrics',{}).get('elements',{});ae=a.get('metrics',{}).get('elements',{})
 for rs,as_ in pairs.items():
  rr=re.get(rs,[]);aa=ae.get(as_,[])
  if len(rr)!=len(aa):continue
  for i,(rv,av) in enumerate(zip(rr,aa)):
   for attr in attrs:
    if attr in rv and attr in av and rv[attr]!=av[attr]:findings.append({'case':rp.stem,'source':rs,'app':as_,'index':i,'attribute':attr,'reference':rv[attr],'actual':av[attr]})
pathlib.Path(str(app).replace('-matrix','-common-style-audit.json')).write_text(json.dumps(findings,indent=2)+'\n')
groups=collections.defaultdict(list)
for f in findings:groups[(f['source'],f['attribute'],f['reference'],f['actual'],f['case'].split('-')[-2])].append(f['case'])
for key,cases in groups.items():print(key,'count',len(cases))
