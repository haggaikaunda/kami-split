const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const sharp = require('/Users/haggaikaunda/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const [source, output] = process.argv.slice(2);
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
(async () => {
  await fs.mkdir(output, {recursive: true});
  const manifest = [];
  const previous = await fs.readFile(path.join(output, 'image-manifest.json'), 'utf8').then(JSON.parse).catch(() => ({files: []}));
  const cached = new Map(previous.files.map(file => [file.sourceName, file]));
  const names = (await fs.readdir(source)).sort().filter(name => /\.(png|json)$/.test(name));
  let next = 0;
  await Promise.all(Array.from({length: 3}, async () => {
  while (next < names.length) {
    const name = names[next++];
    const original = await fs.readFile(path.join(source, name));
    if (name.endsWith('.json')) {
      await fs.writeFile(path.join(output, name), original);
      manifest.push({sourceName: name, file: name, sha256: sha(original)});
      continue;
    }
    const prior = cached.get(name);
    if (prior?.sourcePngSha256 === sha(original)) {
      const bytes = await fs.readFile(path.join(output, prior.file)).catch(() => null);
      if (bytes && sha(bytes) === prior.sha256) { manifest.push(prior); continue; }
    }
    const decoded = await sharp(original).ensureAlpha().raw().toBuffer({resolveWithObject: true});
    const canWebp = decoded.info.width <= 16383 && decoded.info.height <= 16383;
    const file = canWebp ? name.replace(/\.png$/, '.webp') : name;
    const converted = canWebp ? await sharp(original).webp({lossless:true, effort:4}).toBuffer() : original;
    const roundTrip = await sharp(converted).ensureAlpha().raw().toBuffer({resolveWithObject:true});
    if (sha(decoded.data) !== sha(roundTrip.data) || decoded.info.width !== roundTrip.info.width || decoded.info.height !== roundTrip.info.height) throw new Error('Pixel verification failed: '+name);
    await fs.writeFile(path.join(output, file), converted);
    manifest.push({sourceName:name,file,width:decoded.info.width,height:decoded.info.height,sourcePngSha256:sha(original),sha256:sha(converted),decodedRgbaSha256:sha(decoded.data),losslessPixelVerification:true});
  }
  }));
  manifest.sort((a,b) => a.sourceName.localeCompare(b.sourceName));
  await fs.writeFile(path.join(output, 'image-manifest.json'), JSON.stringify({note:'Original pixels preserved. PNG-to-WebP conversion is lossless and each decoded RGBA payload was verified identical; files beyond WebP dimension limits retain PNG. Original capture JSON is unchanged; sourceName maps its PNG names to archive files.',files:manifest},null,2)+'\n');
  process.stdout.write(JSON.stringify({source,output,files:manifest.length})+'\n');
})();
