from pathlib import Path
import re,json,sys
root=Path(sys.argv[1]); paths=[root/'docs/application/expenses-ledger.md',root/'docs/design/issue-227-implementation.md',root/'docs/design/issue-227-parity-matrix.md',*(root/'docs/design/evidence/issue-227').rglob('*.md')];issues=[];count=0
for p in paths:
 for url in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if url.startswith(('https:','http:','mailto:','#')):continue
  target=url.strip('<>').split('#')[0]
  if not target:continue
  count+=1
  if not (p.parent/target).exists():issues.append({'file':str(p.relative_to(root)),'target':url})
print(json.dumps({'localLinksChecked':count,'missing':issues},indent=2))
if issues:sys.exit(1)
