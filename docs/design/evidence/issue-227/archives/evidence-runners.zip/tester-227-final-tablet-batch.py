import os, subprocess, json, hashlib, time
from pathlib import Path
root=Path('/Users/haggaikaunda/.codex/worktrees/issue-227-design-parity/kami-split')
node='/Users/haggaikaunda/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
e=os.environ.copy();e['PATH']=str(Path(node).parent)+':'+e['PATH'];e['PLAYWRIGHT_MODULE']='/Users/haggaikaunda/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright';e['SHARP_MODULE']='/Users/haggaikaunda/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp';e['CHROME_PATH']='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';e['BROWSER_ORIGIN']='http://localhost:3229';e['WIDTHS']='1280,1440,768,390,320'
prefix=e['EVIDENCE_PREFIX'];sha=e['APP_SHA'];build=e['APP_BUILD'];batch=e['BATCH']
assert (root/'apps/web/.next/BUILD_ID').read_text().strip()==build
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
jobs={
 'normal':[('matrix',str(root/'scripts/visual-parity-browser.cjs')),('overlays',str(root/'scripts/visual-parity-browser.cjs'))],
 'responsive':[('independent','/private/tmp/tester-227-acceptance.cjs'),('extended','/private/tmp/tester-227-extended.cjs'),('create-dialog','/private/tmp/tester-227-create-dialog.cjs'),('edit-text','/private/tmp/tester-227-edit-text.cjs')],
 'focused':[('action-proof','/private/tmp/tester-227-action-proof.cjs'),('chart-help','/private/tmp/tester-227-chart-help.cjs'),('selected','/private/tmp/tester-227-selected.cjs'),('populated-filter','/private/tmp/tester-227-populated-filter.cjs'),('selected-overlays','/private/tmp/tester-227-selected-compare.cjs'),('selected-labels','/private/tmp/tester-227-selected-labels.cjs'),('filter-proof','/private/tmp/tester-227-final-filter-proof.cjs'),('interactions',str(root/'scripts/visual-parity-interactions.cjs'))]
}[batch]
results=[]
for name,runner in jobs:
 out=Path(prefix+'-'+name);out.mkdir(parents=True,exist_ok=True);env=e.copy();env['OUTPUT_DIR']=str(out)
 if name=='overlays':env.update(COMPARE_ONLY='1',APP_EVIDENCE_DIR=prefix+'-matrix',REFERENCE_EVIDENCE_DIR='/private/tmp/kami-227-standards-reference')
 if name=='selected-overlays':env['APP_PREFIX']=prefix
 started=time.time();print('START',name,flush=True)
 with open(prefix+'-'+name+'.log','w') as log:
  log.write(f'Independent browser evidence\nApplication commit: {sha}\nProduction build: {build}\nRunner: {runner}\nSynthetic origin: http://localhost:3229\n\n');log.flush()
  p=subprocess.run([node,runner],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert (root/'apps/web/.next/BUILD_ID').read_text().strip()==build
 metadata={'applicationCommit':sha,'buildId':build,'origin':'http://localhost:3229','synthetic':True,'runner':runner,'runnerSHA256':hashlib.sha256(Path(runner).read_bytes()).hexdigest(),'exitCode':p.returncode,'elapsedSeconds':round(time.time()-started,2),'referenceCommit':'3824ce6a878e00d6e417bff8b0e1f7d1988f33e7'}
 (out/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n');results.append({'name':name,**metadata});Path(prefix+'-'+batch+'-batch.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,'exit',p.returncode,'elapsed',metadata['elapsedSeconds'],flush=True)
