from pathlib import Path
import sys,zipfile,re,json,hashlib
src, target, stem = Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
split = len(sys.argv)>4 and sys.argv[4]=='widths'
manifest_path=src/'image-manifest.json'
files=sorted([manifest_path]+[src/item['file'] for item in json.loads(manifest_path.read_text())['files']]) if manifest_path.exists() else sorted(p for p in src.iterdir() if p.is_file())
assert all(p.is_file() for p in files), 'Missing current manifest file'
for p in files:
 if p.suffix in ['.json','.log','.cjs','.md']:
  s=p.read_text(); assert not re.search(r'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}|postgres(?:ql)?://[^\s]+:[^\s]+@|(?:access_token|refresh_token|service_role)\s*["\x27:]\s*["\x27][^"\x27\s]{8,}',s),p
records=[]
for width in ([1440,1280,768,390,320] if split else [None]):
 name=stem+(f'-{width}' if width else '')+'.zip'; dest=target/name
 chosen=[p for p in files if not split or f'-{width}-' in p.name or p.name in ['capture.json','results.json','image-manifest.json','provenance.json','comparison.json']]
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in chosen:z.write(p,p.name)
 assert dest.stat().st_size<50_000_000, (name,dest.stat().st_size)
 records.append({'file':name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(chosen),'viewportWidth':width})
print(json.dumps(records,indent=2))
